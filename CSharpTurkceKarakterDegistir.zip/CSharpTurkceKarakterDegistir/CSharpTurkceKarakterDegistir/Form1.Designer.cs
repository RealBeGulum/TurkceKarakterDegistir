﻿namespace CSharpTurkceKarakterDegistir
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.DisplayLBLPanel = new System.Windows.Forms.Panel();
            this.TrDisplayLbl = new System.Windows.Forms.Label();
            this.DisplayRTxtBox = new System.Windows.Forms.RichTextBox();
            this.TRtxtBox = new System.Windows.Forms.TextBox();
            this.Panel3 = new System.Windows.Forms.Panel();
            this.TrLbl = new System.Windows.Forms.Label();
            this.ENGtxtBox = new System.Windows.Forms.TextBox();
            this.ConvertBTN = new System.Windows.Forms.Button();
            this.Panel4 = new System.Windows.Forms.Panel();
            this.EngLbl = new System.Windows.Forms.Label();
            this.TRCntxMStrp = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.TRKopyalaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TRYapistirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TRTemizleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ENGCntxMStrp = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.ENGKopyalaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ENGYapistirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ENGTemizleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.DisplayLBLPanel.SuspendLayout();
            this.Panel3.SuspendLayout();
            this.Panel4.SuspendLayout();
            this.TRCntxMStrp.SuspendLayout();
            this.ENGCntxMStrp.SuspendLayout();
            this.SuspendLayout();
            // 
            // DisplayLBLPanel
            // 
            this.DisplayLBLPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.DisplayLBLPanel.Controls.Add(this.TrDisplayLbl);
            this.DisplayLBLPanel.Controls.Add(this.DisplayRTxtBox);
            this.DisplayLBLPanel.Location = new System.Drawing.Point(15, 245);
            this.DisplayLBLPanel.Name = "DisplayLBLPanel";
            this.DisplayLBLPanel.Size = new System.Drawing.Size(979, 356);
            this.DisplayLBLPanel.TabIndex = 14;
            // 
            // TrDisplayLbl
            // 
            this.TrDisplayLbl.Location = new System.Drawing.Point(382, 6);
            this.TrDisplayLbl.Name = "TrDisplayLbl";
            this.TrDisplayLbl.Size = new System.Drawing.Size(183, 13);
            this.TrDisplayLbl.TabIndex = 1;
            this.TrDisplayLbl.Text = "::: Tespit Edilen Karakterler :::";
            this.TrDisplayLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DisplayRTxtBox
            // 
            this.DisplayRTxtBox.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.DisplayRTxtBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DisplayRTxtBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.DisplayRTxtBox.DetectUrls = false;
            this.DisplayRTxtBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.DisplayRTxtBox.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.DisplayRTxtBox.Location = new System.Drawing.Point(3, 22);
            this.DisplayRTxtBox.Name = "DisplayRTxtBox";
            this.DisplayRTxtBox.ReadOnly = true;
            this.DisplayRTxtBox.Size = new System.Drawing.Size(971, 329);
            this.DisplayRTxtBox.TabIndex = 1;
            this.DisplayRTxtBox.Text = "";
            this.DisplayRTxtBox.TextChanged += new System.EventHandler(this.DisplayRTxtBox_TextChanged);
            // 
            // TRtxtBox
            // 
            this.TRtxtBox.ContextMenuStrip = this.TRCntxMStrp;
            this.TRtxtBox.Location = new System.Drawing.Point(15, 39);
            this.TRtxtBox.MaxLength = 2147483647;
            this.TRtxtBox.Multiline = true;
            this.TRtxtBox.Name = "TRtxtBox";
            this.TRtxtBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.TRtxtBox.Size = new System.Drawing.Size(446, 200);
            this.TRtxtBox.TabIndex = 11;
            this.TRtxtBox.TextChanged += new System.EventHandler(this.TRtxtBox_TextChanged);
            // 
            // Panel3
            // 
            this.Panel3.AutoSize = true;
            this.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Panel3.Controls.Add(this.TrLbl);
            this.Panel3.Location = new System.Drawing.Point(15, 19);
            this.Panel3.Name = "Panel3";
            this.Panel3.Size = new System.Drawing.Size(446, 20);
            this.Panel3.TabIndex = 16;
            // 
            // TrLbl
            // 
            this.TrLbl.Location = new System.Drawing.Point(145, 3);
            this.TrLbl.Name = "TrLbl";
            this.TrLbl.Size = new System.Drawing.Size(94, 13);
            this.TrLbl.TabIndex = 0;
            this.TrLbl.Text = "::: Türkçe Metin :::";
            this.TrLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ENGtxtBox
            // 
            this.ENGtxtBox.ContextMenuStrip = this.ENGCntxMStrp;
            this.ENGtxtBox.Location = new System.Drawing.Point(548, 39);
            this.ENGtxtBox.MaxLength = 2147483647;
            this.ENGtxtBox.Multiline = true;
            this.ENGtxtBox.Name = "ENGtxtBox";
            this.ENGtxtBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.ENGtxtBox.Size = new System.Drawing.Size(446, 200);
            this.ENGtxtBox.TabIndex = 13;
            // 
            // ConvertBTN
            // 
            this.ConvertBTN.Location = new System.Drawing.Point(467, 39);
            this.ConvertBTN.Name = "ConvertBTN";
            this.ConvertBTN.Size = new System.Drawing.Size(75, 200);
            this.ConvertBTN.TabIndex = 15;
            this.ConvertBTN.Text = "Değiştir";
            this.ConvertBTN.UseVisualStyleBackColor = true;
            this.ConvertBTN.Click += new System.EventHandler(this.ConvertBTN_Click);
            // 
            // Panel4
            // 
            this.Panel4.AutoSize = true;
            this.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Panel4.Controls.Add(this.EngLbl);
            this.Panel4.Location = new System.Drawing.Point(548, 19);
            this.Panel4.Name = "Panel4";
            this.Panel4.Size = new System.Drawing.Size(446, 20);
            this.Panel4.TabIndex = 17;
            // 
            // EngLbl
            // 
            this.EngLbl.Location = new System.Drawing.Point(145, 3);
            this.EngLbl.Name = "EngLbl";
            this.EngLbl.Size = new System.Drawing.Size(117, 13);
            this.EngLbl.TabIndex = 0;
            this.EngLbl.Text = "::: Değiştirilmiş Metin :::";
            this.EngLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TRCntxMStrp
            // 
            this.TRCntxMStrp.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TRKopyalaToolStripMenuItem,
            this.TRYapistirToolStripMenuItem,
            this.TRTemizleToolStripMenuItem});
            this.TRCntxMStrp.Name = "KopyalaCntxMStrp";
            this.TRCntxMStrp.Size = new System.Drawing.Size(117, 70);
            // 
            // TRKopyalaToolStripMenuItem
            // 
            this.TRKopyalaToolStripMenuItem.Name = "TRKopyalaToolStripMenuItem";
            this.TRKopyalaToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.TRKopyalaToolStripMenuItem.Text = "Kopyala";
            this.TRKopyalaToolStripMenuItem.Click += new System.EventHandler(this.TRKopyalaToolStripMenuItem_Click);
            // 
            // TRYapistirToolStripMenuItem
            // 
            this.TRYapistirToolStripMenuItem.Name = "TRYapistirToolStripMenuItem";
            this.TRYapistirToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.TRYapistirToolStripMenuItem.Text = "Yapıştır";
            this.TRYapistirToolStripMenuItem.Click += new System.EventHandler(this.TRYapistirToolStripMenuItem_Click);
            // 
            // TRTemizleToolStripMenuItem
            // 
            this.TRTemizleToolStripMenuItem.Name = "TRTemizleToolStripMenuItem";
            this.TRTemizleToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.TRTemizleToolStripMenuItem.Text = "Temizle";
            this.TRTemizleToolStripMenuItem.Click += new System.EventHandler(this.TRTemizleToolStripMenuItem_Click);
            // 
            // ENGCntxMStrp
            // 
            this.ENGCntxMStrp.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ENGKopyalaToolStripMenuItem,
            this.ENGYapistirToolStripMenuItem,
            this.ENGTemizleToolStripMenuItem});
            this.ENGCntxMStrp.Name = "KopyalaCntxMStrp";
            this.ENGCntxMStrp.Size = new System.Drawing.Size(117, 70);
            // 
            // ENGKopyalaToolStripMenuItem
            // 
            this.ENGKopyalaToolStripMenuItem.Name = "ENGKopyalaToolStripMenuItem";
            this.ENGKopyalaToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.ENGKopyalaToolStripMenuItem.Text = "Kopyala";
            this.ENGKopyalaToolStripMenuItem.Click += new System.EventHandler(this.ENGKopyalaToolStripMenuItem_Click);
            // 
            // ENGYapistirToolStripMenuItem
            // 
            this.ENGYapistirToolStripMenuItem.Name = "ENGYapistirToolStripMenuItem";
            this.ENGYapistirToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.ENGYapistirToolStripMenuItem.Text = "Yapıştır";
            this.ENGYapistirToolStripMenuItem.Click += new System.EventHandler(this.ENGYapistirToolStripMenuItem_Click);
            // 
            // ENGTemizleToolStripMenuItem
            // 
            this.ENGTemizleToolStripMenuItem.Name = "ENGTemizleToolStripMenuItem";
            this.ENGTemizleToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.ENGTemizleToolStripMenuItem.Text = "Temizle";
            this.ENGTemizleToolStripMenuItem.Click += new System.EventHandler(this.ENGTemizleToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1014, 606);
            this.Controls.Add(this.DisplayLBLPanel);
            this.Controls.Add(this.TRtxtBox);
            this.Controls.Add(this.Panel3);
            this.Controls.Add(this.ENGtxtBox);
            this.Controls.Add(this.ConvertBTN);
            this.Controls.Add(this.Panel4);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Türkçe Karakter Temizle";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.DisplayLBLPanel.ResumeLayout(false);
            this.Panel3.ResumeLayout(false);
            this.Panel4.ResumeLayout(false);
            this.TRCntxMStrp.ResumeLayout(false);
            this.ENGCntxMStrp.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Panel DisplayLBLPanel;
        internal System.Windows.Forms.Label TrDisplayLbl;
        internal System.Windows.Forms.RichTextBox DisplayRTxtBox;
        internal System.Windows.Forms.TextBox TRtxtBox;
        internal System.Windows.Forms.Panel Panel3;
        internal System.Windows.Forms.Label TrLbl;
        internal System.Windows.Forms.TextBox ENGtxtBox;
        internal System.Windows.Forms.Button ConvertBTN;
        internal System.Windows.Forms.Panel Panel4;
        internal System.Windows.Forms.Label EngLbl;
        internal System.Windows.Forms.ContextMenuStrip TRCntxMStrp;
        internal System.Windows.Forms.ToolStripMenuItem TRKopyalaToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem TRYapistirToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem TRTemizleToolStripMenuItem;
        internal System.Windows.Forms.ContextMenuStrip ENGCntxMStrp;
        internal System.Windows.Forms.ToolStripMenuItem ENGKopyalaToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem ENGYapistirToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem ENGTemizleToolStripMenuItem;
    }
}

