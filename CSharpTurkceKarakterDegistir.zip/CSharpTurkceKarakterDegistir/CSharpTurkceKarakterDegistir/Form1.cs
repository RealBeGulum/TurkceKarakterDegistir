﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

//_-_-__-_-__-_-__-_-__-_-__-_-__-_-__-_-__-_-_
///////// Coded by eodev/#RealBeGulum \\\\\\\\\
//See more: https://eodev.com/profil/realbegulum-5896105/solved
//_-_-__-_-__-_-__-_-__-_-__-_-__-_-__-_-__-_-_


using System.Text.RegularExpressions;

namespace CSharpTurkceKarakterDegistir
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            TRtxtBox.Text = "Türkçe karakter değiştirme.         EODEV/#RealBeGulum";
        }

        private void TRKopyalaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(TRtxtBox.Text);
        }

        private void TRYapistirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TRtxtBox.Text = TRtxtBox.Text.Insert(TRtxtBox.SelectionStart, Clipboard.GetText(TextDataFormat.UnicodeText));
        }

        private void TRTemizleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TRtxtBox.Text = string.Empty;
        }

        private void ENGKopyalaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(ENGtxtBox.Text);
        }

        private void ENGYapistirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ENGtxtBox.Text = ENGtxtBox.Text.Insert(ENGtxtBox.SelectionStart, Clipboard.GetText(TextDataFormat.UnicodeText));
        }

        private void ENGTemizleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ENGtxtBox.Text = string.Empty;
        }

        private void TRtxtBox_TextChanged(object sender, EventArgs e)
        {
            DisplayRTxtBox.Text = TRtxtBox.Text;
        }

        private void DisplayRTxtBox_TextChanged(object sender, EventArgs e)
        {
            foreach (Match m in Regex.Matches(DisplayRTxtBox.Text, "[İıÜüĞğŞşÇçÖö]"))
            {
                DisplayRTxtBox.Select(m.Index, m.Length);
                DisplayRTxtBox.SelectionColor = Color.Red;
            }
        }

        private void ConvertBTN_Click(object sender, EventArgs e)
        {
            string s = TRtxtBox.Text;
            char[] TrChars = { 'İ', 'ı', 'Ü', 'ü', 'Ğ', 'ğ', 'Ş', 'ş', 'Ç', 'ç', 'Ö', 'ö' };
            char[] EngChars = { 'I', 'i', 'U', 'u', 'G', 'g', 'S', 's', 'C', 'c', 'O', 'o' };
            int i = 0;
            while (i < TrChars.Length)
            {
                s = s.Replace(TrChars[i], EngChars[i]);
                i += 1;
            }
            ENGtxtBox.Text = s;
        }
    }
}
