﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.TRtxtBox = New System.Windows.Forms.TextBox()
        Me.TRCntxMStrp = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.TRKopyalaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TRYapistirToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TRTemizleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ENGtxtBox = New System.Windows.Forms.TextBox()
        Me.ENGCntxMStrp = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ENGKopyalaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ENGYapistirToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ENGTemizleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DisplayLBLPanel = New System.Windows.Forms.Panel()
        Me.TrDisplayLbl = New System.Windows.Forms.Label()
        Me.DisplayRTxtBox = New System.Windows.Forms.RichTextBox()
        Me.ConvertBTN = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.TrLbl = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.EngLbl = New System.Windows.Forms.Label()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.TRCntxMStrp.SuspendLayout()
        Me.ENGCntxMStrp.SuspendLayout()
        Me.DisplayLBLPanel.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.SuspendLayout()
        '
        'TRtxtBox
        '
        Me.TRtxtBox.ContextMenuStrip = Me.TRCntxMStrp
        Me.TRtxtBox.Location = New System.Drawing.Point(15, 32)
        Me.TRtxtBox.MaxLength = 2147483647
        Me.TRtxtBox.Multiline = True
        Me.TRtxtBox.Name = "TRtxtBox"
        Me.TRtxtBox.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.TRtxtBox.Size = New System.Drawing.Size(446, 200)
        Me.TRtxtBox.TabIndex = 0
        '
        'TRCntxMStrp
        '
        Me.TRCntxMStrp.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TRKopyalaToolStripMenuItem, Me.TRYapistirToolStripMenuItem, Me.TRTemizleToolStripMenuItem})
        Me.TRCntxMStrp.Name = "KopyalaCntxMStrp"
        Me.TRCntxMStrp.Size = New System.Drawing.Size(117, 70)
        '
        'TRKopyalaToolStripMenuItem
        '
        Me.TRKopyalaToolStripMenuItem.Name = "TRKopyalaToolStripMenuItem"
        Me.TRKopyalaToolStripMenuItem.Size = New System.Drawing.Size(116, 22)
        Me.TRKopyalaToolStripMenuItem.Text = "Kopyala"
        '
        'TRYapistirToolStripMenuItem
        '
        Me.TRYapistirToolStripMenuItem.Name = "TRYapistirToolStripMenuItem"
        Me.TRYapistirToolStripMenuItem.Size = New System.Drawing.Size(116, 22)
        Me.TRYapistirToolStripMenuItem.Text = "Yapıştır"
        '
        'TRTemizleToolStripMenuItem
        '
        Me.TRTemizleToolStripMenuItem.Name = "TRTemizleToolStripMenuItem"
        Me.TRTemizleToolStripMenuItem.Size = New System.Drawing.Size(116, 22)
        Me.TRTemizleToolStripMenuItem.Text = "Temizle"
        '
        'ENGtxtBox
        '
        Me.ENGtxtBox.ContextMenuStrip = Me.ENGCntxMStrp
        Me.ENGtxtBox.Location = New System.Drawing.Point(548, 32)
        Me.ENGtxtBox.MaxLength = 2147483647
        Me.ENGtxtBox.Multiline = True
        Me.ENGtxtBox.Name = "ENGtxtBox"
        Me.ENGtxtBox.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.ENGtxtBox.Size = New System.Drawing.Size(446, 200)
        Me.ENGtxtBox.TabIndex = 2
        '
        'ENGCntxMStrp
        '
        Me.ENGCntxMStrp.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ENGKopyalaToolStripMenuItem, Me.ENGYapistirToolStripMenuItem, Me.ENGTemizleToolStripMenuItem})
        Me.ENGCntxMStrp.Name = "KopyalaCntxMStrp"
        Me.ENGCntxMStrp.Size = New System.Drawing.Size(117, 70)
        '
        'ENGKopyalaToolStripMenuItem
        '
        Me.ENGKopyalaToolStripMenuItem.Name = "ENGKopyalaToolStripMenuItem"
        Me.ENGKopyalaToolStripMenuItem.Size = New System.Drawing.Size(116, 22)
        Me.ENGKopyalaToolStripMenuItem.Text = "Kopyala"
        '
        'ENGYapistirToolStripMenuItem
        '
        Me.ENGYapistirToolStripMenuItem.Name = "ENGYapistirToolStripMenuItem"
        Me.ENGYapistirToolStripMenuItem.Size = New System.Drawing.Size(116, 22)
        Me.ENGYapistirToolStripMenuItem.Text = "Yapıştır"
        '
        'ENGTemizleToolStripMenuItem
        '
        Me.ENGTemizleToolStripMenuItem.Name = "ENGTemizleToolStripMenuItem"
        Me.ENGTemizleToolStripMenuItem.Size = New System.Drawing.Size(116, 22)
        Me.ENGTemizleToolStripMenuItem.Text = "Temizle"
        '
        'DisplayLBLPanel
        '
        Me.DisplayLBLPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.DisplayLBLPanel.Controls.Add(Me.TrDisplayLbl)
        Me.DisplayLBLPanel.Controls.Add(Me.DisplayRTxtBox)
        Me.DisplayLBLPanel.Location = New System.Drawing.Point(15, 238)
        Me.DisplayLBLPanel.Name = "DisplayLBLPanel"
        Me.DisplayLBLPanel.Size = New System.Drawing.Size(979, 356)
        Me.DisplayLBLPanel.TabIndex = 5
        '
        'TrDisplayLbl
        '
        Me.TrDisplayLbl.Location = New System.Drawing.Point(390, 6)
        Me.TrDisplayLbl.Name = "TrDisplayLbl"
        Me.TrDisplayLbl.Size = New System.Drawing.Size(183, 13)
        Me.TrDisplayLbl.TabIndex = 1
        Me.TrDisplayLbl.Text = "::: Tespit Edilen Karakterler :::"
        Me.TrDisplayLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'DisplayRTxtBox
        '
        Me.DisplayRTxtBox.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.DisplayRTxtBox.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.DisplayRTxtBox.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.DisplayRTxtBox.DetectUrls = False
        Me.DisplayRTxtBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.DisplayRTxtBox.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.DisplayRTxtBox.Location = New System.Drawing.Point(3, 22)
        Me.DisplayRTxtBox.Name = "DisplayRTxtBox"
        Me.DisplayRTxtBox.ReadOnly = True
        Me.DisplayRTxtBox.Size = New System.Drawing.Size(971, 329)
        Me.DisplayRTxtBox.TabIndex = 1
        Me.DisplayRTxtBox.Text = ""
        '
        'ConvertBTN
        '
        Me.ConvertBTN.Location = New System.Drawing.Point(467, 32)
        Me.ConvertBTN.Name = "ConvertBTN"
        Me.ConvertBTN.Size = New System.Drawing.Size(75, 200)
        Me.ConvertBTN.TabIndex = 6
        Me.ConvertBTN.Text = "Değiştir"
        Me.ConvertBTN.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(15, 12)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(446, 20)
        Me.Panel1.TabIndex = 7
        '
        'Panel2
        '
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.Panel3)
        Me.Panel2.Location = New System.Drawing.Point(-1, -1)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(446, 20)
        Me.Panel2.TabIndex = 8
        '
        'Panel3
        '
        Me.Panel3.AutoSize = True
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel3.Controls.Add(Me.TrLbl)
        Me.Panel3.Location = New System.Drawing.Point(-1, -1)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(446, 20)
        Me.Panel3.TabIndex = 9
        '
        'TrLbl
        '
        Me.TrLbl.Location = New System.Drawing.Point(153, 3)
        Me.TrLbl.Name = "TrLbl"
        Me.TrLbl.Size = New System.Drawing.Size(94, 13)
        Me.TrLbl.TabIndex = 0
        Me.TrLbl.Text = "::: Türkçe Metin :::"
        Me.TrLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(153, 3)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(94, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "::: Türkçe Metin :::"
        '
        'EngLbl
        '
        Me.EngLbl.Location = New System.Drawing.Point(153, 3)
        Me.EngLbl.Name = "EngLbl"
        Me.EngLbl.Size = New System.Drawing.Size(117, 13)
        Me.EngLbl.TabIndex = 0
        Me.EngLbl.Text = "::: Değiştirilmiş Metin :::"
        Me.EngLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel4
        '
        Me.Panel4.AutoSize = True
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel4.Controls.Add(Me.EngLbl)
        Me.Panel4.Location = New System.Drawing.Point(548, 12)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(446, 20)
        Me.Panel4.TabIndex = 10
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1009, 606)
        Me.Controls.Add(Me.TRtxtBox)
        Me.Controls.Add(Me.ENGtxtBox)
        Me.Controls.Add(Me.ConvertBTN)
        Me.Controls.Add(Me.DisplayLBLPanel)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Panel4)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Türkçe Karakter Temizle"
        Me.TRCntxMStrp.ResumeLayout(False)
        Me.ENGCntxMStrp.ResumeLayout(False)
        Me.DisplayLBLPanel.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents TRtxtBox As TextBox
    Friend WithEvents ENGtxtBox As TextBox
    Friend WithEvents DisplayLBLPanel As Panel
    Friend WithEvents ConvertBTN As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents TrLbl As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents EngLbl As Label
    Friend WithEvents Panel4 As Panel
    Friend WithEvents TrDisplayLbl As Label
    Friend WithEvents DisplayRTxtBox As RichTextBox
    Friend WithEvents TRCntxMStrp As ContextMenuStrip
    Friend WithEvents TRKopyalaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TRTemizleToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ENGCntxMStrp As ContextMenuStrip
    Friend WithEvents ENGKopyalaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ENGTemizleToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TRYapistirToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ENGYapistirToolStripMenuItem As ToolStripMenuItem
End Class
