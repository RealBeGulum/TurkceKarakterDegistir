﻿'_-_-__-_-__-_-__-_-__-_-__-_-__-_-__-_-__-_-_
'/////// Coded by eodev/#RealBeGulum \\\\\\\\\
'See more: https://eodev.com/profil/realbegulum-5896105/solved
'_-_-__-_-__-_-__-_-__-_-__-_-__-_-__-_-__-_-_


Imports System.Text.RegularExpressions

Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TRtxtBox.Text = "Türkçe karakter değiştirme.         EODEV/#RealBeGulum"
    End Sub

    Private Sub TRKopyalaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TRKopyalaToolStripMenuItem.Click
        Clipboard.SetText(TRtxtBox.Text)
    End Sub

    Private Sub TRYapistirToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TRYapistirToolStripMenuItem.Click
        TRtxtBox.Text = TRtxtBox.Text.Insert(TRtxtBox.SelectionStart, Clipboard.GetText(TextDataFormat.UnicodeText))
    End Sub

    Private Sub TRTemizleToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TRTemizleToolStripMenuItem.Click
        TRtxtBox.Text = String.Empty
    End Sub

    Private Sub ENGKopyalaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ENGKopyalaToolStripMenuItem.Click
        Clipboard.SetText(ENGtxtBox.Text)
    End Sub

    Private Sub ENGYapistirToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ENGYapistirToolStripMenuItem.Click
        ENGtxtBox.Text = ENGtxtBox.Text.Insert(ENGtxtBox.SelectionStart, Clipboard.GetText(TextDataFormat.UnicodeText))
    End Sub

    Private Sub ENGTemizleToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ENGTemizleToolStripMenuItem.Click
        ENGtxtBox.Text = String.Empty
    End Sub

    Private Sub TRtxtBox_TextChanged(sender As Object, e As EventArgs) Handles TRtxtBox.TextChanged
        DisplayRTxtBox.Text = TRtxtBox.Text
    End Sub

    Private Sub DisplayRTxtBox_TextChanged(sender As Object, e As EventArgs) Handles DisplayRTxtBox.TextChanged
        For Each m As Match In Regex.Matches(DisplayRTxtBox.Text, "[İıÜüĞğŞşÇçÖö]")
            DisplayRTxtBox.Select(m.Index, m.Length)
            DisplayRTxtBox.SelectionColor = Color.Red
        Next
    End Sub

    Private Sub ConvertBTN_Click(sender As Object, e As EventArgs) Handles ConvertBTN.Click
        Dim s As String = TRtxtBox.Text
        Dim TrChars As Char() = {"İ", "ı", "Ü", "ü", "Ğ", "ğ", "Ş", "ş", "Ç", "ç", "Ö", "ö"}
        Dim EngChars As Char() = {"I", "i", "U", "u", "G", "g", "S", "s", "C", "c", "O", "o"}
        Dim i As Integer = 0
        Do While i < TrChars.Length
            s = Replace(s, TrChars(i), EngChars(i))
            i += 1
        Loop
        ENGtxtBox.Text = s
    End Sub
End Class
